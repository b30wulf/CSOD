/*
 * TGrdSystemTime.java
 *
 * Created on 5 ��� 2009 �., 14:23
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package Guardant;

/**
 * TGrdSystemTime
 * 
 * @author KovalenkoI
 */
public class TGrdSystemTime
{
    /** The year (1601 - 2099) */
    public short wYear;
    /** The month (January = 1, February = 2, ...) */
    public short wMonth;
    /** The day of the week (Sunday = 0, Monday = 1, ...) */
    public short wDayOfWeek;
    /** The day of the month (1-31) */
    public short wDay;
    /** The hour (0-23) */
    public short wHour;
    /** The minute (0-59) */
    public short wMinute;
    /** The second (0-59) */
    public short wSecond;
    /** The millisecond (0-999) */
    public short wMilliseconds;
}
