/*
 * GrdAT.java
 *
 * Created on 23 ������ 2007 �., 1:41
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package Guardant;

/** ��������� ������ Guardant Stealth */
public class GrdAT
{
    /** Basic method */
    public static final GrdAT Algo0=new GrdAT(0);
    
    /** Character method */
    public static final GrdAT AlgoASCII=new GrdAT(1);
    
    /** File method */
    public static final GrdAT AlgoFile=new GrdAT(2);
    
    long value;
    
    GrdAT(long _value)
    {
        value=_value;
    }
    public long getValue()
    {
        return value;
    }
}

