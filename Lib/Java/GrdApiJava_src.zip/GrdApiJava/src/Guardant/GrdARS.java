/*
 * GrdARS.java
 *
 * Created on 23 ������ 2007 �., 1:08
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package Guardant;

//- Guardant Stealth I & II Algorithm Request Size -----------------------------
/*     GrdARS_AutoProtect=  4,   // For automatic protection
        GrdARS_Fast=        32,   // For CodeInit (EnCode/DeCode) operation
        GrdARS_Random=       4,   // Random number generator
        GrdARS_DEMO=         4,   // For Transform operation
        GrdARS_GSII64=       8,   // For GSII64 TransformEx operation
 */


/** Guardant Stealth III: ������ ������� � ���������� � ���������� ������� �� ��������� */
public class GrdARS
{
    /** GSII64 for automatic protection and use in API */
    public static final GrdARS GSII64=new GrdARS( 8);
    
    /** HASH64 for automatic protection and use in API */
    public static final GrdARS HASH64=new GrdARS( 8);
    
    /** RAND64 for automatic protection and use in API */
    public static final GrdARS RAND64=new GrdARS( 8);
    
    /** Protected Item for read only data. Can update via Safety Guardant Remote Update */
    public static final GrdARS READ_ONLY=new GrdARS( 8);
    
    /** Protected Item for read/write data. Can update at protected application runtime */
    public static final GrdARS READ_WRITE=new GrdARS( 8);
    
    /** GSII64 demo algo for use in guardant examlpes */
    public static final GrdARS GSII64_DEMO=new GrdARS( 8);
    
    /** HASH64 demo algo for use in guardant examlpes */
    public static final GrdARS HASH64_DEMO=new GrdARS( 8);
    
    /** ECC160 for automatic protection & use in API */
    public static final GrdARS ECC160=new GrdARS( 20);
    
    /** AES128 for automatic protection & use in API */
    public static final GrdARS AES128=new GrdARS( 16);
    
    /** SHA256 for automatic protection & use in API */
    public static final GrdARS HASH_SHA256=new GrdARS( 32);

    long value;
  
    public long getValue()
    {
        return value;
    }
    
    GrdARS(long _value)
    {
        value=_value;
    }
}
