package Guardant;

/** ������ ������ */
public class GrdDM
{
    /** Guardant Stealth LPT */
    public static final GrdDM GS1L=new GrdDM( 0);
    
    /** Guardant Stealth USB */
    public static final GrdDM GS1U=new GrdDM( 1);
    
    /** Guardant Fidus LPT */
    public static final GrdDM GF1L=new GrdDM( 2);
    
    /** Guardant Stealth II LPT */
    public static final GrdDM GS2L=new GrdDM( 3);
    
    /** Guardant Stealth II USB */
    public static final GrdDM GS2U=new GrdDM( 4);
    
    /** Guardant Stealth III USB */
    public static final GrdDM GS3U=new GrdDM( 5);
    
    /** Guardant Fidus USB */
    public static final GrdDM GF1U=new GrdDM( 6);

    /** Guardant Stealth III Sign/Time USB */
    public static final GrdDM SignUSB=new GrdDM( 7);
    public static final GrdDM GS3SU=new GrdDM( 7);

    /** Guardant Stealth Code */
    public static final GrdDM CodeUSB=new GrdDM( 8);
    public static final GrdDM GCU=new GrdDM( 8);
    
    /** ����� ���������� ������� */
    public static final GrdDM Total=new GrdDM( 9);
    
    /* ������ ���������������� �����  */
    public static final GrdDM GRD_DRV=new GrdDM( 0);
    public static final GrdDM USB_HID=new GrdDM( 1);
    
    long value;
    public GrdDM(long _value)
    {
        value=_value;
    }
    public long getValue()
    {
        return value;
    }
}
