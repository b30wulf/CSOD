/*
 * TGrdCodeInfo.java
 *
 * Created on 6 ��� 2009 �., 18:36
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package Guardant;

public class TGrdCodeInfo
{
    /** Flash start address for Loadable Code. */
    public long dwStartAddr;
    /** Flash size for Loadable Code. */
    public long dwCodeSizeMax;
    /** Flash sector size for Loadable Code. */
    public long dwCodeSectorSize;
    /** RAM start address for Loadable Code. */
    public long dwStartRamAddr;
    /** RAM size for Loadable Code. */
    public long dwRamSizeMax;
    /** Reserved. */
    public long dwReserved;
    /** ... */
    TGrdCodePublicData PublicDataLoadableCode = new TGrdCodePublicData();
    /** Hash of Loadable Code. */
    public byte[] Hash = new byte[32];
    /** Reserved[64]. */
    public byte[] Reserved = new byte[64];
}
