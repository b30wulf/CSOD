/*
 * TGrdCodePublicData.java
 *
 * Created on 6 ��� 2009 �., 18:37
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package Guardant;

public class TGrdCodePublicData
{
    /** Loadable Code version. */
    public byte bLoadableCodeVersion;
    /** Reserved. */
    public byte bReserved0;
    /** LoadableCode state. */
    public byte bState;
    /** Reserved. */
    public byte bReserved;
    /* Date and time of load. */
    public long dwLoadingDate;
}
