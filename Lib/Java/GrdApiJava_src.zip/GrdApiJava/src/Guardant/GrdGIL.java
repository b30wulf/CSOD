/*
 * GrdGIL.java
 *
 * Created on 23 ������ 2007 �., 1:02
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package Guardant;

/** ��������� ��� ��������� ���������� � ������� ������� GrdGetInfo.
 *  <br/>���������� � ������� �����. */
public class GrdGIL
{
    /** Local or remote dongle */
    public static final GrdGIL Remote=new GrdGIL(0x3000);
    
    /** ID of current dongle */
    public static final GrdGIL ID=new GrdGIL( 0x3001);
    
    /** Model of current dongle */
    public static final GrdGIL Model=new GrdGIL( 0x3002);
    
    /** Interface of current dongle */
    public static final GrdGIL Interface=new GrdGIL( 0x3003);
    
    //	GrdGIL_LockID=new GrdGIL(          0x3004);
    
    /** Lock counter value for current dongle */
    public static final GrdGIL LockCounter=new GrdGIL( 0x3005);
    
    /** Current dongle memory address */
    public static final GrdGIL Seek=new GrdGIL( 0x3006);
    
    /** Driver       version =new GrdGIL(0x04801234=new GrdGIL(4.80.12.34) */
    public static final GrdGIL DrvVers=new GrdGIL( 0x4000);
    
    /** Driver       build */
    public static final GrdGIL DrvBuild=new GrdGIL( 0x4001);
    
    /** LPT port address =new GrdGIL(0 =new GrdGIL(=new GrdGIL( USB) */
    public static final GrdGIL PortLPT=new GrdGIL( 0x4002);
    
    long value;
    GrdGIL(long _value)
    {
        value=_value;
    }
    public long getValue()
    {
        return value;
    }    
}

