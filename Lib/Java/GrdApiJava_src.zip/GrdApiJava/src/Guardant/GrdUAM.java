/*
 * GrdUAM.java
 *
 * Created on 23 ������ 2007 �., 0:51
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package Guardant;

/** UAM-������ ����� ������ ��� ������������� � �������� GrdRead � GrdWrite */
public class GrdUAM
{
    /** 00h Programm number */
    public static final GrdUAM bNProg=new GrdUAM(30 - 30);
    
    /** 01h Version */
    public static final GrdUAM bVer=new GrdUAM(31 - 30);
    
    /** 02h Serial number */
    public static final GrdUAM wSN=new GrdUAM(32 - 30);
    
    /** 04h Bit mask */
    public static final GrdUAM wMask=new GrdUAM(34 - 30);
    
    /** 06h Counter #1 =new GrdUAM(GP) */
    public static final GrdUAM wGP=new GrdUAM(36 - 30);
    
    /** 08h Current network license limit */
    public static final GrdUAM wRealLANRes=new GrdUAM(38 - 30);
    
    /** 0Ah Index */
    public static final GrdUAM dwIndex=new GrdUAM(40 - 30);
    
    /** 0Eh User data, algorithm descriptors */
    public static final GrdUAM abAlgoAddr=new GrdUAM(44 - 30);
    
    long value;
    GrdUAM(long _value)
    {
        value=_value;
    }
    
    public long getValue()
    {
        return value;
    }
}
