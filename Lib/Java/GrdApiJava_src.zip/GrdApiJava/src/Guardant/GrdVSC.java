/*
 * GrdVSC.java
 *
 * Created on 27 ������ 2009 �., 12:17
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package Guardant;

/**
 * Software implemented asymmetric cryptoalgorithms
 * @author KovalenkoI
 */
public class GrdVSC 
{
    /** ECC160 message size */
    public static final GrdVSC ECC160 = new GrdVSC(0);

    long value;
    public long getValue()
    {
        return value;
    }
    GrdVSC(long _value)
    {
        value=_value;
    }   
}
